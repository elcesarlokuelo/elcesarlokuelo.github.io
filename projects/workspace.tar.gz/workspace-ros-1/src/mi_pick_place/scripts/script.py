#!/usr/bin/env python3

import rospy
import moveit_commander
import sys

def main():
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('pick_place_script')

    group = moveit_commander.MoveGroupCommander("manipulator")

    # --- Punto 1: posicion de "pick" ---
    pose_pick = group.get_current_pose().pose
    pose_pick.position.x = 0.4
    pose_pick.position.y = 0.1
    pose_pick.position.z = 0.3
    group.set_pose_target(pose_pick)

    rospy.loginfo("Planificando movimiento hacia pick...")
    group.go(wait=True)
    group.stop()
    group.clear_pose_targets()

    rospy.sleep(1)

    # --- Punto 2: posicion de "place" ---
    pose_place = group.get_current_pose().pose
    pose_place.position.x = 0.2
    pose_place.position.y = -0.3
    pose_place.position.z = 0.3
    group.set_pose_target(pose_place)

    rospy.loginfo("Planificando movimiento hacia place...")
    group.go(wait=True)
    group.stop()
    group.clear_pose_targets()

    rospy.loginfo("Secuencia completada.")

if __name__ == '__main__':
    main()